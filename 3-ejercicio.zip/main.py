# 3-Crear un programa que muestre los primeros 10 números pares a partir del producto de (10 x 10).
print ( "los primeros 10 numeros pares del producto 10x10 es: \ n " )
para  x  en el  rango ( 100 , 122 ):
 si  x  %  2  ==  0 :
    print ( x , end  =  "" )