numero  =  int ( input ( 'Ingresar un numero entre 0 y 9:' ))
si  numero  ==  1 :
 imprimir ( 'UNO' )
si  numero  ==  2 :
 imprimir ( 'Dos' )
si  numero  ==  3 :
 imprimir ( 'Tres' )
si  numero  ==  4 :
 imprimir ( 'cuatro' )
si  numero  ==  5 :
 imprimir ( 'cinco' )
si  numero  ==  6 :
 imprimir ( 'Seis' )
si  numero  ==  7 :
 imprimir ( 'Siete' )
si  numero  ==  8 :
 imprimir ( 'Ocho' )
si  numero  ==  9 :
 imprimir ( 'Nueve' )
otra cosa :
 si  numero  ! =  0  y  numero  >  9 :
    print ( 'Su numero es menor que 0 o mayor que 9' )