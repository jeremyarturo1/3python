# 4-Crear un programa que muestre las letras de la Z (mayúscula) a la A (mayúscula, descendiendo).
import  cadena
def  listAlphabet ():
   lista de retorno ( cadena . ascii_uppercase )
imprimir ( 'alfabeto en mayuscula' )
imprimir ( listAlphabet ())